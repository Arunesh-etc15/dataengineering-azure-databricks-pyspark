# Databricks notebook source
client_id="64047e6b-ad31-44fb-a446-e34687e33233"
tenant_id="4727e249-1807-4b4f-8077-dbc900bba035"
client_secret="m7V8Q~GhDuDKiXdscYGiklHDzsGLXEDxHgxVTcJE"




# COMMAND ----------

spark.conf.set("fs.azure.account.auth.type.formula1databricksdl.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.formula1databricksdl.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.formula1databricksdl.dfs.core.windows.net", client_id)
spark.conf.set("fs.azure.account.oauth2.client.secret.formula1databricksdl.dfs.core.windows.net", client_secret)
spark.conf.set("fs.azure.account.oauth2.client.endpoint.formula1databricksdl.dfs.core.windows.net", f"https://login.microsoftonline.com/{tenant_id}/oauth2/token")

# COMMAND ----------

dbutils.fs.ls("abfss://presentation@formula1databricksdl.dfs.core.windows.net")

# COMMAND ----------


display(spark.read.csv("abfss://demo@formula1databricksdl.dfs.core.windows.net/circuits.csv"))


# COMMAND ----------

