# Databricks notebook source

spark.conf.set("fs.azure.account.auth.type.formula1databricksdl.dfs.core.windows.net", "SAS")
spark.conf.set("fs.azure.sas.token.provider.type.formula1databricksdl.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.sas.FixedSASTokenProvider")
spark.conf.set("fs.azure.sas.fixed.token.formula1databricksdl.dfs.core.windows.net", "sp=rl&st=2026-01-04T16:40:20Z&se=2026-01-05T00:55:20Z&spr=https&sv=2024-11-04&sr=c&sig=WzW%2F6zVq%2FySvaROFcUBAjhzILXl7reb%2BbLaYa1EevcQ%3D")

# COMMAND ----------

dbutils.fs.ls("abfss://demo@formula1databricksdl.dfs.core.windows.net")

# COMMAND ----------


display(spark.read.csv("abfss://demo@formula1databricksdl.dfs.core.windows.net/circuits.csv"))


# COMMAND ----------

