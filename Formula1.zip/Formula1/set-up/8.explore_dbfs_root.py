# Databricks notebook source
dbutils.fs.ls('/')

# COMMAND ----------

#dbutils.fs.ls('dbfs:/databricks-datasets/samples/people')

df = spark.read.json("dbfs:/databricks-datasets/samples/people/people.json")
display(df)


# COMMAND ----------

df=spark.sql("select * from samples.bakehouse.media_customer_reviews")
display(df)

# COMMAND ----------

