# Databricks notebook source
spark.conf.set(
    "fs.azure.account.key.formula1databricksdl.dfs.core.windows.net",
    "WZTJDAr/2Hv8oQRlmOxXxhBzzsw87miaxIWi+kk2VFqmNXDXmYC5ixVUjWWm31mSeUXUrNxXX7CI+AStehpzwA=="
)

# COMMAND ----------

dbutils.fs.ls("abfss://presentation@formula1databricksdl.dfs.core.windows.net")

# COMMAND ----------


display(spark.read.csv("abfss://demo@formula1databricksdl.dfs.core.windows.net/circuits.csv"))


# COMMAND ----------

