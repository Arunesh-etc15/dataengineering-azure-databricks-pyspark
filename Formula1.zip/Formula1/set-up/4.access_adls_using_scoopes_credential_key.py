# Databricks notebook source


# COMMAND ----------

dbutils.fs.ls("abfss://demo@formula1databricksdl.dfs.core.windows.net")

# COMMAND ----------


display(spark.read.csv("abfss://demo@formula1databricksdl.dfs.core.windows.net/circuits.csv"))


# COMMAND ----------

