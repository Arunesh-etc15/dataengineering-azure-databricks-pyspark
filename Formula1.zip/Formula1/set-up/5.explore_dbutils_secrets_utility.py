# Databricks notebook source
display(dbutils.secrets.listScopes())
display(dbutils.secrets.list("formula1-scope"))
display(dbutils.secrets.get(scope = "formula1-scope", key = "formula1-dl-account-key"))

# COMMAND ----------

dbutils.secrets.list("formula1-scope")

# COMMAND ----------

formula1_dl_account_key= dbutils.secrets.get(scope = "formula1-scope", key = "formula1-dl-account-key")
spark.conf.set(
    "fs.azure.account.key.formula1databricksdl.dfs.core.windows.net",
    formula1_dl_account_key
)

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

dbutils.fs.ls("abfss://presentation@formula1databricksdl.dfs.core.windows.net")

# COMMAND ----------


display(spark.read.csv("abfss://demo@formula1databricksdl.dfs.core.windows.net/circuits.csv"))


# COMMAND ----------

