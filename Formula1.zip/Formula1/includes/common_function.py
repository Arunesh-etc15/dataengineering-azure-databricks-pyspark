# Databricks notebook source
from pyspark.sql.functions import current_timestamp
def add_ingestion_date(input_def):
    output_df = input_def.withColumn('ingestion_date', current_timestamp())
    return output_df

# COMMAND ----------

