# Databricks notebook source

kafka_bootstrap_servers = "20.197.9.176:9092"
topic = "CodeDecodeTopic"

df = spark.read \
  .format("kafka") \
  .option("kafka.bootstrap.servers", kafka_bootstrap_servers) \
  .option("subscribe", topic) \
  .load()

decoded = df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)")
display(decoded.count())
display(decoded)


# COMMAND ----------

# For local/self-managed Kafka
stream_df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", kafka_bootstrap_servers) \
    .option("subscribe", topic) \
    .load()

# Decode key/value from binary to string
decoded_stream = stream_df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)")
query = decoded_stream.writeStream \
    .outputMode("append") \
    .format("console") \
    .start(trigger='AvailableNow')

query.awaitTermination()

# COMMAND ----------

kafka_bootstrap_servers = "20.197.9.176:9092"
topic = "CodeDecodeTopic"

stream_df = spark.readStream \
  .format("kafka") \
  .option("kafka.bootstrap.servers", kafka_bootstrap_servers) \
  .option("subscribe", topic) \
  .load()

decoded_stream = stream_df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)")

# COMMAND ----------

query = decoded_stream.writeStream \
    .outputMode("append") \
    .format("console") \
    .option("checkpointLocation", "dbfs:/user/arunesh/checkpoints/kafka_listener") \
    .trigger(availableNow=True)\
    .start()

query.awaitTermination()

# COMMAND ----------

display(decoded_stream, checkpointLocation="/mnt/checkpoints/kafka_listener")

# COMMAND ----------

query = decoded_stream.writeStream \
    .format("console") \
    .trigger(availableNow=True) \
    .start()


query.awaitTermination()

# COMMAND ----------

display(decoded_stream)