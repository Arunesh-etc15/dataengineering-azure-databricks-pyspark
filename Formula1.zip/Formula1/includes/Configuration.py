# Databricks notebook source
raw_folder_path="abfss://raw@formula1databricksdl.dfs.core.windows.net"
processed_folder_path="abfs://processed@formula1databricksdl.dfs.core.windows.net"
presentation_folder_path="abfss://presentation@formula1databricksdl.dfs.core.windows.net"   

# COMMAND ----------

