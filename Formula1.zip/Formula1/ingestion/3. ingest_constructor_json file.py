# Databricks notebook source
spark.conf.set(
    "fs.azure.account.key.formula1databricksdl.dfs.core.windows.net",
    "WZTJDAr/2Hv8oQRlmOxXxhBzzsw87miaxIWi+kk2VFqmNXDXmYC5ixVUjWWm31mSeUXUrNxXX7CI+AStehpzwA=="
)

# COMMAND ----------

# MAGIC
# MAGIC %run "../includes/Configuration"
# MAGIC

# COMMAND ----------

# MAGIC %run "../includes/common_function"

# COMMAND ----------

constructors_schema = "constructorId INT, constructorRef STRING, name STRING, nationality STRING,url STRING"


# COMMAND ----------

constructors_df = spark.read.schema(constructors_schema).json(f"{raw_folder_path}/constructors.json")

# COMMAND ----------

display(constructors_df)

# COMMAND ----------

constructor_dropped_df= constructors_df.drop("url")
display(constructor_dropped_df)

# COMMAND ----------

from pyspark.sql.functions import col,concat,lit,current_timestamp
constructor_final_droped_df = constructor_dropped_df.withColumnRenamed("constructorId","constructor_id")     \
                                             .withColumnRenamed("constructorRef","constructor_ref")
                                            # .withColumn("ingestion_date",current_timestamp())
constructor_final_df=add_ingestion_date(constructor_final_droped_df)

display(constructor_final_df)                                                                                                         

# COMMAND ----------

display(constructor_final_df)

# COMMAND ----------

constructor_final_df.write.mode("overwrite").parquet(f"{processed_folder_path}/constructors")

# COMMAND ----------

parquet_df = spark.read.parquet(f"{processed_folder_path}/constructors")
display(parquet_df)

# COMMAND ----------

