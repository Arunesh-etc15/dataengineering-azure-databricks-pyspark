# Databricks notebook source
var_result=dbutils.notebook.run("1.ingest_circuts_file",0,{"p_data_source":"Ergast"})

# COMMAND ----------

display(var_result)

# COMMAND ----------

var_result=dbutils.notebook.run("2.ingest_race_file",0,{"p_data_source":"Ergast"})

# COMMAND ----------

var_result=dbutils.notebook.run("3. ingest_constructor_json file",0,{"p_data_source":"Ergast"})

# COMMAND ----------

var_result=dbutils.notebook.run("4.ingest_driver_file",0,{"p_data_source":"Ergast"})

# COMMAND ----------

var_result=dbutils.notebook.run("5.ingest_result_file",0,{"p_data_source":"Ergast"})

# COMMAND ----------

var_result=dbutils.notebook.run("6.ingest_pitstop_file",0,{"p_data_source":"Ergast"})

# COMMAND ----------

var_result=dbutils.notebook.run("7.ingest_laps_time_file",0,{"p_data_source":"Ergast"})

# COMMAND ----------

var_result=dbutils.notebook.run("8.ingest_qualifying_file",0,{"p_data_source":"Ergast"})