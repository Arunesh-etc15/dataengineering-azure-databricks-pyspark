# Databricks notebook source
spark.conf.set(
    "fs.azure.account.key.formula1databricksdl.dfs.core.windows.net",
    "WZTJDAr/2Hv8oQRlmOxXxhBzzsw87miaxIWi+kk2VFqmNXDXmYC5ixVUjWWm31mSeUXUrNxXX7CI+AStehpzwA=="
)

# COMMAND ----------

# MAGIC %run "../includes/Configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_function"

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

lap_time_schema=StructType(fields=[
     StructField("raceId", IntegerType(), False),
    StructField("driverId", IntegerType(), True),
    StructField("lap", IntegerType(), True),
    StructField("position", IntegerType(), True),
    StructField("time", StringType(), True),
    StructField("milliseconds", IntegerType(), True)
])

# COMMAND ----------

lap_times_df=spark.read.schema(lap_time_schema) \
                      .csv(f"{raw_folder_path}/lap_times")

# COMMAND ----------

display(lap_times_df)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp
final_lap_times_coulmn_df = lap_times_df.withColumnRenamed("driverId", "driver_id") \
                                 .withColumnRenamed("raceId", "race_id")
                             #   .withColumn("ingestion_date", current_timestamp())

final_lap_times_df=add_ingestion_date(final_lap_times_coulmn_df)
display(final_lap_times_df)

# COMMAND ----------

final_lap_times_df.write.mode("overwrite").parquet(f"{processed_folder_path}/lap_times")

# COMMAND ----------

parquetFile = spark.read.parquet(f"{processed_folder_path}/lap_times")
display(parquetFile)

# COMMAND ----------

