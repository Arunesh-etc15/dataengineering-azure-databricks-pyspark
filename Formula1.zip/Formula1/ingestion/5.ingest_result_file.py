# Databricks notebook source
spark.conf.set(
    "fs.azure.account.key.formula1databricksdl.dfs.core.windows.net",
    "WZTJDAr/2Hv8oQRlmOxXxhBzzsw87miaxIWi+kk2VFqmNXDXmYC5ixVUjWWm31mSeUXUrNxXX7CI+AStehpzwA=="
)

# COMMAND ----------

# MAGIC %run "../includes/Configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_function"

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

result_schema=StructType(fields=[StructField("resultId", IntegerType(), False),
                                   StructField("raceId", IntegerType(), False),
                                   StructField("driverId", IntegerType(), False),
                                   StructField("constructorId", IntegerType(), False),
                                   StructField("number", IntegerType(), True),
                                   StructField("grid", IntegerType(), True),
                                   StructField("position", IntegerType(), True) ,
                                   StructField("positionText", StringType(), True),
                                   StructField("positionOrder", IntegerType(), True),
                                   StructField("points", FloatType(), True),
                                   StructField("laps", IntegerType(), True),
                                   StructField("time", StringType(), True),
                                   StructField("milliseconds", IntegerType(), True),
                                   StructField("fastestLap", IntegerType(), True),
                                   StructField("rank", IntegerType(), True),
                                   StructField("fastestLapTime", StringType(), True),
                                   StructField("fastestLapSpeed", FloatType(), True),
                                   StructField("statusId", StringType(), True)])
race_df=spark.read.schema(result_schema)

# COMMAND ----------

result_df=spark.read.schema(result_schema).json(f"{raw_folder_path}/results.json")

# COMMAND ----------

result_final_df=result_df.drop("statusId")

# COMMAND ----------

display(result_final_df.count())
display(result_final_df)

# COMMAND ----------

result_final_df.write.mode("overwrite").parquet(f"{processed_folder_path}/results")

# COMMAND ----------

parquest_result_df=spark.read.parquet(f"{processed_folder_path}/results")

# COMMAND ----------

display(parquest_result_df)


# COMMAND ----------

