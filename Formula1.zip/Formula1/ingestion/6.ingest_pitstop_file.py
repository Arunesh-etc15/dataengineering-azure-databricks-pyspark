# Databricks notebook source
spark.conf.set(
    "fs.azure.account.key.formula1databricksdl.dfs.core.windows.net",
    "WZTJDAr/2Hv8oQRlmOxXxhBzzsw87miaxIWi+kk2VFqmNXDXmYC5ixVUjWWm31mSeUXUrNxXX7CI+AStehpzwA=="
)

# COMMAND ----------

# MAGIC %run "../includes/Configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_function"

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

pit_stop_schema=StructType(fields=[
    StructField("raceId", IntegerType(), False),
    StructField("driverId", IntegerType(), True),
    StructField("stop", StringType(), True),
    StructField("lap", IntegerType(), True),
    StructField("time", StringType(), True),
    StructField("duration", StringType(), True),
    StructField("milliseconds", IntegerType(), True)
])

# COMMAND ----------

pit_stop_df=spark.read.schema(pit_stop_schema) \
                      .option("multiLine", True)\
                      .json(f"{raw_folder_path}/pit_stops.json")

# COMMAND ----------

display(pit_stop_df)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp
final_pit_stops_cloumn_df = pit_stop_df.withColumnRenamed("driverId", "driver_id") \
                                 .withColumnRenamed("raceId", "race_id")
                              #  .withColumn("ingestion_date", current_timestamp())
final_pit_stops_df=add_ingestion_date(final_pit_stops_cloumn_df)
display(final_pit_stops_df)

# COMMAND ----------

final_pit_stops_df.write.mode("overwrite").parquet(f"{processed_folder_path}/pit_stops")

# COMMAND ----------

parquetFile = spark.read.parquet(f"{processed_folder_path}/pit_stops")
display(parquetFile)

# COMMAND ----------

