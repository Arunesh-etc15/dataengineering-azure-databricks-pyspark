# Databricks notebook source
spark.conf.set(
    "fs.azure.account.key.formula1databricksdl.dfs.core.windows.net",
    "WZTJDAr/2Hv8oQRlmOxXxhBzzsw87miaxIWi+kk2VFqmNXDXmYC5ixVUjWWm31mSeUXUrNxXX7CI+AStehpzwA=="
)

# COMMAND ----------

# MAGIC %run "../includes/Configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_function"

# COMMAND ----------

ace_df=spark.read \
                 .option("header",True) \
                 .option("inferSchema",True)\
                 .csv(f"{raw_folder_path}/races.csv")  

# COMMAND ----------

display(ace_df)

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, DateType

races_schema=StructType(fields=[

    StructField("raceId", IntegerType(), False),
    StructField("year", StringType(), True),
    StructField("round", StringType(), True),
    StructField("circuitId", IntegerType(), True),
    StructField("name", StringType(), True),
    StructField("date", DateType(), True),
    StructField("time", StringType(), True),
    StructField("url", StringType(), True)
])
races_df=spark.read \
    .option("header",True) \
    .schema(races_schema) \
    .csv(f"{raw_folder_path}/races.csv")  

# COMMAND ----------

display(races_df)

# COMMAND ----------

from pyspark.sql.functions import when,col
races_df.withColumn("year", when(col("year") == 2009, 2025).otherwise(col("year")))

# COMMAND ----------

display(races_df)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, col, concat, lit,to_timestamp,try_to_timestamp

# races_with_timesatmp_df=races_df.withColumn("ingestion_date",current_timestamp()) 
#                                # .withColumn("race_timestamp",(to_timestamp(concat(col("date"),lit(" "),col("time")),"yyyy-MM-dd HH:mm:ss")))

# COMMAND ----------

races_with_timesatmp_df=add_ingestion_date(races_df)

# COMMAND ----------

display(races_with_timesatmp_df)

# COMMAND ----------

race_selected_df=races_with_timesatmp_df.select(col("raceId").alias("race_id"),
                                                col("year").alias("race_year"),
                                                col("round"),
                                                col("circuitId").alias("circuit_id"),
                                                col("name"),
                                                col("ingestion_date"))
display(race_selected_df)

# COMMAND ----------

race_selected_df.write.mode("overwrite").parquet(f"{processed_folder_path}/races")

# COMMAND ----------

parquet_df=spark.read.parquet(f"{processed_folder_path}/races")

# COMMAND ----------

display(parquet_df)

# COMMAND ----------

