# Databricks notebook source
spark.conf.set(
    "fs.azure.account.key.formula1databricksdl.dfs.core.windows.net",
    "WZTJDAr/2Hv8oQRlmOxXxhBzzsw87miaxIWi+kk2VFqmNXDXmYC5ixVUjWWm31mSeUXUrNxXX7CI+AStehpzwA=="
)

# COMMAND ----------

# MAGIC %run "../includes/Configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_function"

# COMMAND ----------


from pyspark.sql.types import *

# COMMAND ----------

name_schema=StructType([
  StructField("forename",StringType(),True),
  StructField("surname",StringType(),True)
  ])

# COMMAND ----------

driver_schema=StructType([
  StructField("driverId",IntegerType(),False),
  StructField("driverRef",StringType(),True),
  StructField("number",IntegerType(),True),
  StructField("code",StringType(),True),
  StructField("name",name_schema),
  StructField("dob",DateType(),True),
  StructField("nationality",StringType(),True),
  StructField("url",StringType(),True)
  ])

# COMMAND ----------

driver_df = spark.read.schema(driver_schema).json(f"{raw_folder_path}/drivers.json")
display(driver_df)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,concat,lit,col

driver_column_renamed_df=driver_df.withColumnRenamed("driverId","driver_id") \
                           .withColumnRenamed("driverRef","driver_ref") \
                           .withColumn("name",concat(col("name.forename"),lit(" "),col("name.surname")))
driver_column_df=add_ingestion_date(driver_column_renamed_df)


# COMMAND ----------

display(driver_column_df)

# COMMAND ----------

diver_final_df=driver_column_df.drop("url")
display(diver_final_df)

# COMMAND ----------

diver_final_df.write.mode("overwrite").parquet(f"{processed_folder_path}/drivers")

# COMMAND ----------

parquetFile = spark.read.parquet(f"{processed_folder_path}/drivers")

# COMMAND ----------

display(parquetFile)

# COMMAND ----------

