# Databricks notebook source
spark.conf.set(
    "fs.azure.account.key.formula1databricksdl.dfs.core.windows.net",
    "WZTJDAr/2Hv8oQRlmOxXxhBzzsw87miaxIWi+kk2VFqmNXDXmYC5ixVUjWWm31mSeUXUrNxXX7CI+AStehpzwA=="
)

# COMMAND ----------

# MAGIC %run "../includes/Configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_function"

# COMMAND ----------

dbutils.widgets.text("p_data_source","")
var_data_source=dbutils.widgets.get("p_data_source")

# COMMAND ----------

var_data_source

# COMMAND ----------

display(raw_folder_path)

# COMMAND ----------

dbutils.fs.ls("abfss://raw@formula1databricksdl.dfs.core.windows.net")

# COMMAND ----------

dbutils.fs.ls("abfss://raw@formula1databricksdl.dfs.core.windows.net/lap_times")


# COMMAND ----------


circuts_df=spark.read.csv(f"{raw_folder_path}/circuits.csv")
display(circuts_df)


# COMMAND ----------

circuts_df.show(n=50,truncate=False)


# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType

circuts_schema=StructType(fields=[

    StructField("circuitId", IntegerType(), False),
    StructField("circuitRef", StringType(), True),
    StructField("name", StringType(), True),
    StructField("location", StringType(), True),
    StructField("country", StringType(), True),
    StructField("lat", DoubleType(), True),
    StructField("lng", DoubleType(), True),
    StructField("alt", IntegerType(), True),
    StructField("url", StringType(), True)
])
circuits_df=spark.read \
    .option("header",True) \
    .schema(circuts_schema) \
    .csv(f"{raw_folder_path}/circuits.csv")  

# COMMAND ----------

display(circuits_df)

# COMMAND ----------

from pyspark.sql.functions import col, lit
circuits_Renamed_df=circuits_df.withColumnRenamed("circuitId","circuit_id") \
    .withColumnRenamed("circuitRef","circuit_ref") \
    .withColumnRenamed("lat","latitude") \
    .withColumnRenamed("lng","longitude") \
    .withColumnRenamed("alt","altitude") \
    .withColumn("datasource", lit(var_data_source))


# COMMAND ----------

circuits_final_df=add_ingestion_date(circuits_Renamed_df)
display(circuits_final_df)

# COMMAND ----------

circuits_final_df.write.mode("overwrite").parquet(f"{processed_folder_path}/circuits")

# COMMAND ----------

spark.read.parquet(f"{processed_folder_path}/circuits").display()

# COMMAND ----------

dbutils.notebook.exit("Success")