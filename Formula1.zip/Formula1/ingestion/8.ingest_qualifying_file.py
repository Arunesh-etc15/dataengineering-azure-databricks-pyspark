# Databricks notebook source
spark.conf.set(
    "fs.azure.account.key.formula1databricksdl.dfs.core.windows.net",
    "WZTJDAr/2Hv8oQRlmOxXxhBzzsw87miaxIWi+kk2VFqmNXDXmYC5ixVUjWWm31mSeUXUrNxXX7CI+AStehpzwA=="
)

# COMMAND ----------

# MAGIC %run "../includes/Configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_function"

# COMMAND ----------

from pyspark.sql.types import *

# COMMAND ----------

qulaifying_schema=StructType(fields=[
    StructField("qualifyId", IntegerType(), False),
    StructField("raceId", IntegerType(), True),
    StructField("driverId", IntegerType(), True),
    StructField("constructorId", IntegerType(), True),
    StructField("number", IntegerType(), True),
    StructField("position", IntegerType(), True),
    StructField("q1", StringType(), True),
    StructField("q2", StringType(), True),
    StructField("q3", StringType(), True)
])

# COMMAND ----------

qualifying_df=spark.read.schema(qulaifying_schema) \
                      .option("multiLine", True)\
                      .json(f"{raw_folder_path}/qualifying")

# COMMAND ----------

display(qualifying_df)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp
final_qualifying_df = qualifying_df.withColumnRenamed("constructorId", "constructor_id")\
                                        .withColumnRenamed("qualifyId", "qualify_id") \
                                        .withColumnRenamed("driverId", "driver_id") \
                                        .withColumnRenamed("raceId", "race_id")
 #                                       .withColumn("ingestion_date", current_timestamp())
 
final_qualifying_df_df=add_ingestion_date(final_qualifying_df)
display(final_qualifying_df_df)

# COMMAND ----------

final_qualifying_df_df.write.mode("overwrite").parquet(f"{processed_folder_path}/qualifying")

# COMMAND ----------

parquetFile = spark.read.parquet(f"{processed_folder_path}/qualifying")
display(parquetFile)

# COMMAND ----------

