-- Databricks notebook source
--create database demo

-- COMMAND ----------

create database if not exists demo

-- COMMAND ----------

show databases

-- COMMAND ----------

describe database demo

-- COMMAND ----------

describe database extended demo

-- COMMAND ----------

select current_database()

-- COMMAND ----------

use demo

-- COMMAND ----------

select current_database()

-- COMMAND ----------

show tables

-- COMMAND ----------

-- MAGIC %python
-- MAGIC spark.conf.set(
-- MAGIC     "fs.azure.account.key.formula1databricksdl.dfs.core.windows.net",
-- MAGIC     "WZTJDAr/2Hv8oQRlmOxXxhBzzsw87miaxIWi+kk2VFqmNXDXmYC5ixVUjWWm31mSeUXUrNxXX7CI+AStehpzwA=="
-- MAGIC )
-- MAGIC
-- MAGIC

-- COMMAND ----------

-- MAGIC %run "../includes/Configuration"
-- MAGIC

-- COMMAND ----------

-- MAGIC %run "../includes/common_function"

-- COMMAND ----------

-- MAGIC %python
-- MAGIC
-- MAGIC race_result_df=spark.read.parquet(f"{presentation_folder_path}/race_results")

-- COMMAND ----------

-- DBTITLE 1,Cell 14
-- MAGIC %python
-- MAGIC # Save as Delta table (default format for managed tables)
-- MAGIC race_result_df.write.saveAsTable("demo.race_results_python")

-- COMMAND ----------

show tables

-- COMMAND ----------

select count(*) from demo.race_results_python

-- COMMAND ----------

select * from demo.race_results_python where race_year = 2020

-- COMMAND ----------

create table if not exists demo.race_results_sql
as 
select * from demo.race_results_python where race_year = 2020
    

-- COMMAND ----------

select count(*) from race_results_sql

-- COMMAND ----------

show tables

-- COMMAND ----------

-- MAGIC %python
-- MAGIC display(race_result_df.count())

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_result_df.write.format("parquet").option("path", f"{presentation_folder_path}/race_results_ext_py").saveAsTable("demo.race_results_ext_py")