-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set(
-- MAGIC     "fs.azure.account.key.formula1databricksdl.dfs.core.windows.net",
-- MAGIC     "WZTJDAr/2Hv8oQRlmOxXxhBzzsw87miaxIWi+kk2VFqmNXDXmYC5ixVUjWWm31mSeUXUrNxXX7CI+AStehpzwA=="
-- MAGIC )

-- COMMAND ----------

-- MAGIC %python
-- MAGIC "../includes/Configuration"

-- COMMAND ----------

-- MAGIC %python
-- MAGIC "../includes/common_function"

-- COMMAND ----------

CREATE STORAGE CREDENTIAL my_storage_credential
FOR AZURE
WITH AZURE_SERVICE_PRINCIPAL
  CLIENT_ID = "64047e6b-ad31-44fb-a446-e34687e33233",
  TENANT_ID = "4727e249-1807-4b4f-8077-dbc900bba035",
  CLIENT_SECRET = "m7V8Q~GhDuDKiXdscYGiklHDzsGLXEDxHgxVTcJE"
)
COMMENT 'Credential for accessing raw ADLS container';

-- COMMAND ----------

CREATE STORAGE CREDENTIAL my_storage_credential
FOR AZURE
WITH AZURE_MANAGED_IDENTITY
COMMENT 'Credential for accessing ADLS Gen2';

-- COMMAND ----------

create database if not exists f1_raw;

-- COMMAND ----------

create table if not exists f1_raw.circuits(
  circuitId INT,
  circuitRef string,    
  name string,
  location string,
  country string,
  lat double,
  lng double,
  alt int,
  url string
)using csv
options (path="abfss://raw@formula1databricksdl.dfs.core.windows.net/circuits.csv", header="true");
--abfss://unity-catalog-storage@dbstorager4rxkkciemapa.dfs.core.windows.net/7405605800552094

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS f1_raw.circuits (
  circuitId INT,
  circuitRef STRING,
  name STRING,
  location STRING,
  country STRING,
  lat DOUBLE,
  lng DOUBLE,
  alt INT,
  url STRING
)
USING CSV
LOCATION 'abfss://raw@formula1databricksdl.dfs.core.windows.net/circuits/'
OPTIONS (
  header = "true",
  inferSchema = "true"
);