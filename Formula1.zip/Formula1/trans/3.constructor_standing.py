# Databricks notebook source
spark.conf.set(
    "fs.azure.account.key.formula1databricksdl.dfs.core.windows.net",
    "WZTJDAr/2Hv8oQRlmOxXxhBzzsw87miaxIWi+kk2VFqmNXDXmYC5ixVUjWWm31mSeUXUrNxXX7CI+AStehpzwA=="
)

# COMMAND ----------

# MAGIC %run "../includes/Configuration"
# MAGIC

# COMMAND ----------

# MAGIC %run "../includes/common_function"

# COMMAND ----------

race_results_df=spark.read.parquet(f"{presentation_folder_path}/race_results")
display(race_results_df)

# COMMAND ----------

from pyspark.sql.functions import sum, count, when, col
constructor_standing_df=race_results_df.groupBy("race_year","team")\
                .agg(sum("points").alias("total_points")
                ,count(when(col("position")==1,1)).alias("wins"))
display(constructor_standing_df)

# COMMAND ----------

display(constructor_standing_df.filter("race_year=2020"))

# COMMAND ----------

from pyspark.sql.functions import desc,rank
from pyspark.sql.window import Window
driver_rank_spec=Window.partitionBy("race_year").orderBy(desc("total_points"),desc("wins"))
final_driver_df=constructor_standing_df.withColumn("rank",rank().over(driver_rank_spec))
display(final_driver_df.filter("race_year=2020"))  

# COMMAND ----------

